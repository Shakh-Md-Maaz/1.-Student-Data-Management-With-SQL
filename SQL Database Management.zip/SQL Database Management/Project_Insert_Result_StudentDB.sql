USE  studentDB
GO
SELECT * FROM TSP
SELECT * FROM Hobby
SELECT * FROM SubjectTable
SELECT * FROM studentinformation

-- Requirement two for a Clustered Index in any one of the table.

exec sp_helpindex TSP

-- Requirement three for Insert Records into tables using Script. 

go
insert into TSP
values
(101,'USSL'),
(102,'PNTL')

go
insert into Hobby
values
(201,'football'),
(202,'volleyball'),
(203,'basketball')

go
insert into subjectTable
values
(301,'C#'),
(302,'WPDI')

go
insert into studentinformation
values
('DN01','Peter','Mark',1234567,101,201,301),
('DN02','Victor','Gomez',1234568,101,202,301),
('DN02','Victor','Gomez',1234568,101,203,301),
('DN02','Victor','Gomez',1234568,101,201,301),
('DN03','Young','Lee',1234569,102,202,302)

-- Requirement four for Insert Records into any one table using loop.

select * from #temphobby

-- Requirement five for JOIN query to find out details of all the information. 
go
select SI.studentid,SI.studentfirstname+' '+SI.studentlastname as [Name],
SI.Tspid,T.Tspname,SI.phone,SI.hobbyid,H.hobbyname,SI.subjectid,ST.subjectname
from studentinformation as SI
join TSP as T on T.Tspid=SI.Tspid
join Hobby as H on H.hobbyid=SI.hobbyid
join SubjectTable as ST on ST.subjectid=SI.subjectid

-- Requirement six for to find out subject-wise total student using CTE.

go
with TBstudent
as
(select studentid ,count(*) as list from studentinformation group by studentid)
select subjectTable.subjectname, list 
from studentinformation 
join TBstudent on studentinformation.studentid=TBstudent.studentid
join subjectTable on subjectTable.subjectid=studentinformation.subjectid

-- Requirement seven for a sub-Query to find all information of Volleyball.

go
select table2.studentid,table2.studentfirstname+' '+table2.studentlastname as [Name],
Tspid,table2.phone,Hobby.hobbyname,
subjectTable.subjectname from 
(select * from studentinformation
where subjectid in

(select subjectid from subjectTable)) as table2
join Hobby on Hobby.hobbyid=table2.hobbyid
join subjectTable on subjectTable.subjectid=table2.subjectid

-- Requirement eight for a view for Question no -7.

select * from view_information

-- Requiremnt no Nine for a Trigger to show a message when inserting a record into any one of the table.

INSERT INTO Hobby
Values (204,'Cricket')

-- Requirement no ten for a stored procedure to insert, update and delete any of the table of your database.

EXEC insertupdatedelete 'SELECT','','',''
EXEC insertupdatedelete 'UPDATE','','',''
EXEC insertupdatedelete 'INSERT','','',''
EXEC insertupdatedelete 'DELETE','','',''

-- Requirement no eleven for a Scalar function to show hobby by student id.

SELECT dbo.FnHobby(201) as HobbyName FROM Hobby