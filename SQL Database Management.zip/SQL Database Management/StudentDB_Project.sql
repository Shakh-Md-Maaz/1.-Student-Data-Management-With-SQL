--Qus 1 3NF

use master
go
if DB_ID('studentDB') is not null
drop database studentDB
go
create database studentDB
on
(
name ='student_DB',
filename='C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\student_DB.mdf',
size= 25mb,
maxsize= 100 mb,
filegrowth= 5%
)
log on(
name ='student_DB_log',
filename='C:\Program Files\Microsoft SQL Server\MSSQL13.MSSQLSERVER\MSSQL\DATA\student_DB_log.ldf',
size= 2mb,
maxsize= 25 mb,
filegrowth= 1%
)

go
use studentDB
go
create table TSP(
Tspid int primary key nonclustered,
Tspname varchar (15) not null
)

go
create table Hobby(
hobbyid int primary key,
hobbyname varchar (15) not null
)
go
create table SubjectTable(
subjectid int primary key,
subjectname varchar (6) not null
)
go
create table studentinformation(
studentid varchar(6),
studentfirstname varchar (8)not null,
studentlastname varchar (8)not null,
phone int not null,
Tspid int references TSP(Tspid),
hobbyid int references Hobby(hobbyid),
subjectid int references subjectTable(subjectid),
primary key(Tspid,hobbyid,subjectid,studentid)
)

--Qus 2 clustered index

go
create clustered index IX_TSP
on TSP(TSPid)

--Qus 4 insert records loop

go
if OBJECT_ID ('#tempHobby') is not null
drop table #temphobby
create table #temphobby
(hobbyid int,hobbyname varchar (15))

GO
declare @hobbyid int, @hobbyname varchar (15)
declare insert_cursor cursor
for
select * from Hobby
open insert_cursor
fetch next from insert_cursor into
@hobbyid,@hobbyname
while @@FETCH_STATUS <>-1
begin
insert into #temphobby
values
(@hobbyid,@hobbyname)
fetch next from insert_cursor into
@hobbyid,@hobbyname
end
close insert_cursor
Deallocate insert_cursor

--Qus 8 view for Question no-6

go
create view view_information
as
select s.studentid,s.studentfirstname+' '+s.studentlastname as[Name],
s.Tspid,s.phone,h.hobbyname,su.subjectname
 from studentinformation as s
join Hobby as h on h.hobbyid=s.hobbyid
join subjectTable as su on su.subjectid=s.subjectid


--Qus 9 Trigger to show a message when inserting a record into any one of the table

go
create trigger ShowMessageInserting
on Hobby
for
insert,update,delete
as
begin
print 'you can not have any permission '
rollback
end

--Qus 10 stored procedure to update any of the table 

go
create proc insertupdatedelete
@hobbyid int,
@hobbyname varchar (15),
@statementtype varchar (15)=''
as
if @statementtype='select'
begin
select * from Hobby
end

begin
if @statementtype='insert'
begin
insert into Hobby
values
(@hobbyid,@hobbyname)
end

if @statementtype='update'
begin
update Hobby
set hobbyname=@hobbyname
where hobbyid=@hobbyid
end
end

--Qus 11 Scalar function to show hobby wise total student

go
create function FnHobby
(@hobbyid int)
returns varchar (15)
AS
BEGIN
RETURN (select Hobbyname from Hobby where hobbyid=@hobbyid)
END
